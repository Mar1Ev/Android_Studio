package com.example.contral_work_ema;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Sos2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sos2);
    }
}